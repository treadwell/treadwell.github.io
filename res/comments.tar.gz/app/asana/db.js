function Db (asanas, groups) {

    asanas.sort((a, b) => a.seq - b.seq)

    // COMMENT: Where is this function used? What is it for? I see an
    // "addGroup" function defined in asanaSelector, but it has nothing to do
    // with this function. If this function is not used it should be deleted.
    // Since it's it your commit history you can always recover it if need be.
    //
    function addGroup (id, name, idx_array) {
        groups.push({
            id: id,
            name: name,
            series: idx_array
        })
    }

    return {
        asanas,
        groups
    }
}
